

exports.sayHelloInEnglish = function() {
  return "Hello";
};

exports.sayHelloInSwedish = function() {
  return "Hej";
};
