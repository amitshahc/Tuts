var greetings = require("./greetings.js");

console.log("Swedish " +
  greetings.sayHelloInSwedish() +
  " & English " +
  greetings.sayHelloInEnglish());
