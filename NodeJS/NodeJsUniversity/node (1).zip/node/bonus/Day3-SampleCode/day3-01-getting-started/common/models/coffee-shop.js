module.exports = function(CoffeeShop) {

};
