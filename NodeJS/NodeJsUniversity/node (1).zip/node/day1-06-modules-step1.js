// Two standard variable functions.
var sayHelloInEnglish = function() {
  return "Hello";
};

var sayHelloInSwedish = function() {
  return "Hej";
};

console.log("Swedish " +
  sayHelloInSwedish() +
  " & English " +
  sayHelloInEnglish());
