// the rest of the code is in the increment.js and
// math.js files holding those modules.

var inc = require('./increment').increment;
var a = 1;
console.log(inc(a));
